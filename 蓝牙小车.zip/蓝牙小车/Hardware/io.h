#ifndef __IO_H
#define __IO_H

void LightSensor_Init(void);
uint8_t LightSensor1_Get(void);
uint8_t LightSensor2_Get(void);
uint8_t LightSensor3_Get(void);
uint8_t LightSensor4_Get(void);

#define Trig_Port 		GPIOA
#define Trig_Pin 		GPIO_Pin_1
#define Trig_RCC		RCC_APB2Periph_GPIOA

#define Echo_Port 		GPIOA
#define Echo_Pin 	                                   	GPIO_Pin_2
#define Echo_RCC		RCC_APB2Periph_GPIOA
void SR04_Init(void);
void Show_SRDis(void);
float Get_DisVal(void);
void Timer_Init(void);
void Timer_ON(void);
void Timer_OFF(void);

float getacc(void);

void HCSR04_Init();
uint16_t HCSR04_GetValue();


void Timer_Init();

#endif