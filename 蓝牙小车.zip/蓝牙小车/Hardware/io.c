#include "stm32f10x.h"                  // Device header
#include "io.h"
#include "Delay.h"
#include "io.h"



 uint16_t Time;


void TIM4_IRQHandler()		//定时器2的中断函数，不懂直接套用
{
	if(TIM_GetITStatus(TIM4, TIM_IT_Update) == SET)
	{

		if (GPIO_ReadInputDataBit(Echo_Port, Echo_Pin) == 1)
		{
			Time ++;
		}
		TIM_ClearITPendingBit(TIM4, TIM_IT_Update);		//清空标志位
	}
}

void LightSensor_Init(void)
{
	/*开启时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);		//开启GPIOB的时钟
	
	/*GPIO初始化*/
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13| GPIO_Pin_14 |GPIO_Pin_15|GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);						//将PB13引脚初始化为上拉输入
}




/**
  * 函    数：获取当前光敏传感器输出的高低电平
  * 参    数：无
  * 返 回 值：光敏传感器输出的高低电平，范围：0/1
  */
uint8_t LightSensor1_Get(void)
{
	return GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_13);			//返回PB13输入寄存器的状态
}

uint8_t LightSensor2_Get(void)
{
	return GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14);			//返回PB13输入寄存器的状态
}

uint8_t LightSensor3_Get(void)
{
	return GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_15);			//返回PB13输入寄存器的状态
}
uint8_t LightSensor4_Get(void)
{
	return GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_3);			//返回PB13输入寄存器的状态
}


/**
  * 函    数：获取当前光敏传感器输出的高低电平
  * 参    数：无
  * 返 回 值：光敏传感器输出的高低电平，范围：0/1
  */


//超声波测距定时器TIM2 初始化
void Timer_Init(void)
{	//开启定时器时钟
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	//使用内部时钟
	TIM_InternalClockConfig(TIM4);
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;//不分频
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;//向上计数
	TIM_TimeBaseInitStructure.TIM_Period = 65535;//ARR
	TIM_TimeBaseInitStructure.TIM_Prescaler=72-1;//预分频值
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;//CNT到达ARR中断一次
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseInitStructure);
	TIM_SetCounter(TIM4,0);//CNT值清0
}

//开启TIM2定时器
void Timer_ON(void)
{
	TIM_Cmd(TIM4,ENABLE);
}

//关闭TIM2定时器
void Timer_OFF(void)
{
	TIM_Cmd(TIM4,DISABLE);
}

//参数初始化
float Num;
int i=0,Counter,Sum,Dec,CNT_Mean,CN1,CN2;
//超声波模块触发函数
void SR04_Start(void)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_2);//A0置1大于10us
	Delay_us(15);
	GPIO_ResetBits(GPIOA,GPIO_Pin_2);
}

void SR04_Init(void)
{
	Timer_Init();//开启定时器3
	GPIO_InitTypeDef GPIO_InitStructure;//定义初始化结构体
	EXTI_InitTypeDef EXTI_InitStructure;//定义外部中断结构体
	NVIC_InitTypeDef NVIC_InitStructure;//定义NVIC结构体
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);//开GPIO时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);//开AFIO时钟
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource1);
	EXTI_InitStructure.EXTI_Line=EXTI_Line1;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;	
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; 
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;	
	NVIC_Init(&NVIC_InitStructure);
	//脉冲触发端口 Trig=PA0
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	//回波接收端口 Echo=PA1
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	SR04_Start();
}
void EXTI1_IRQHandler(void)
{
	Delay_us(50);
	if(EXTI_GetITStatus(EXTI_Line1) != RESET)
	{	
		Timer_ON();//开始计时
		CN1 = TIM_GetCounter(TIM4);
		while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1));//A1为高电平时一直循环下去
		CN2 = TIM_GetCounter(TIM4);
		Timer_OFF();
		Counter = CN2 - CN1;//获得计数差
		EXTI_ClearITPendingBit(EXTI_Line1);//清除标志位
	}
}
     

float getacc(void)
{for(i=0;i<5;i++)//均值滤波
	{
		SR04_Init();
		Sum+=Counter;
	}
	CNT_Mean=Sum/5;
	Num=CNT_Mean*0.017;//b/5 * 17/1000
	CNT_Mean=Sum/5;
	Num=CNT_Mean*0.017;//b/5 * 17/1000
	Dec=(17*Sum/5)%100;//100取余得到小数点后值
	Sum=0;//更新Sum
	return Num;
}

   float Get_DisVal(void)
{
	return Num;
}                 


//返回超声波测距值

