#ifndef __PWM_H
#define __PWM_H

void PWM_Init1(void);
void PWM_SetCompare3(int Compare);
void PWM_Init2(void);
void PWM_SetCompare1(int Compare);

#endif
