#ifndef __MOTOR_H
#define __MOTOR_H

void Motor_Init(void);
void Motor_SetSpeed1(int8_t Speed);
void Motor_SetSpeed2(int8_t Speed);

void Motor_up(int speed);
void Motor_left(int speed);
void Motor_right(int speed);
void Motor_stop(int speed);
void Motor_leftUP(int speed);
void Motor_rightUP(int speed);
void Motor_leftDOWN(int speed);
void Motor_rightDOWN(int speed);
void Motor_rotate(int speed);
void Motor_back(int speed);


#endif
