#ifndef __HONGWAI_H
#define __HONGWAI_H

void LightSensor_Init(void);
uint8_t LightSensor1_Get(void);
uint8_t LightSensor2_Get(void);




#endif