#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Motor.h"
//#include "Key.h"
#include "io.h"
#include "OLED.h"
#include "Serial.h"



uint8_t Serial_RxData;		
uint8_t Serial_RxFlag;
uint16_t stu=0;		
int speed;

void USART1_IRQHandler(void)
{
	if (USART_GetITStatus(USART1, USART_IT_RXNE) == SET)		//判断是否是USART1的接收事件触发的中断
	{
		Serial_RxData = USART_ReceiveData(USART1);				//读取数据寄存器，存放在接收的数据变量
     Serial_RxData=Serial_RxData;
		Serial_RxFlag = 1;										//置接收标志位变量为1
		USART_ClearITPendingBit(USART1, USART_IT_RXNE);			//清除USART1的RXNE标志位
																//读取数据寄存器会自动清除此标志位
																//如果已经读取了数据寄存器，也可以不执行此代码
   if(Serial_RxData==0x00)//停止
    {
     stu=0;
		}
	  else if(Serial_RxData==0x01)//前进
		{
     stu=1;
		}
    else if(Serial_RxData==0x02)//左转
		{
     stu=2;
		}
    else if(Serial_RxData==0x03)//右转
		{
     stu=3;
		}
    else if(Serial_RxData==0x04)//后退
		{
     stu=4;
		}
    else if(Serial_RxData==0x05)//ys
		{
     stu=5;
		}
    else if(Serial_RxData==0x06)//yx
		{
     stu=6;
		}
    else if(Serial_RxData==0x07)//zs
		{
     stu=7;
		}
    else if(Serial_RxData==0x08)//zx
		{
     stu=8;
		}
    else if(Serial_RxData==0x09)//zx
		{
     stu=9;
		}
    else if(Serial_RxData==0x10)//zx
		{
     speed+=10;
		}
    else if(Serial_RxData==0x11)//zx
		{
     speed-=10;
		}


	}
}





uint8_t KeyNum;		//定义用于接收按键键码的变量
int8_t Speed;		//定义速度变量
float T;
int rag=0;
int main(void)
{
	Serial_Init();
	Motor_Init();
//	LightSensor_Init();
//	SR04_Init();
	
	
	
	int i=0;
	
	while (1)
	{

//Motor_SetSpeed1(20);
Motor_SetSpeed2(20);


//			switch(stu)
//   {
//    case 0: Motor_stop(speed); break;
//    case 1:  Motor_up(speed);break;
//		case 2:  Motor_left(speed);break;
//    case 3:  Motor_right(speed) ; break;
//    case 4:   Motor_back(speed); break;
//    case 5:  Motor_rightUP(speed);    break;
//    case 6:  int speedMotor_rightDOWN(speed); break;
//		case 7:  Motor_leftUP(speed); break;
//    case 8:  Motor_leftDOWN(speed); break;
//    case 9: Motor_rotate(speed); break;

//   }


}
	}
