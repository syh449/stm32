#ifndef __ENCODER_H
#define __ENCODER_H

void Encoder_Init(void);
int16_t Encoder_Get(void);
void Encoder_Init2(void);
int16_t Encoder_Get2(void);



#endif
