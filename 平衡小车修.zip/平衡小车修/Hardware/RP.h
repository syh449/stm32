#ifndef __RP_H
#define __RP_H

void RP_Init(void);
uint16_t RP_GetValue(uint8_t n);

#endif
