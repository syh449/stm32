#ifndef __MOTOR_H
#define __MOTOR_H

void Motor_Init(void);
void Motor_SetPWM1(int16_t PWM);
void Motor_SetPWM2(int16_t PWM);

#endif
