#include "stm32f10x.h"                  // Device header"
#include "OLED.h"
#include "Delay.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h"
#include "MPU6050.h"
#include "PWM.h"
#include "Serial.h"
#include "Delay.h"
#include "LED.h"
#include "Timer.h"
#include "Key.h"
#include "RP.h"
#include "Motor.h"
#include "Encoder.h"

float Pitch,Roll,Yaw;
int x,y,z;
short gyro1,gyro2,gyro3;
short aac[3];

uint8_t KeyNum;
uint16_t Count,sum;
float Target=0, Actual, Out=0,Actual2, Out2=0,Speed=0,Target2=0,a=0.7;
float Kp=0, Ki=0;
float jKp=400, jKi=0, jKd=0;
float Error0, Error1;
int Errorout, Errorlast,ErrorInt;
float jError0, jError1;
float jError0_2,jTarget2=0,jActual2,jOut2,Error1_2,Error0_2,ErrorInt_2,jError1_2;
float jError0,jTarget=3.7, jActual;
int t_out, jOut;
int16_t speed;
int16_t location;
int flag=0;


int Vertical(float target,float ture,float gyro_z)
{
	int t;
	t=jKp*(ture-target)+jKd*gyro_z;
	return t;
}


int Verspeed(int target,int left,int right)
{
	int err,t;
	err=(left+right)-target;
	Errorout=(1-a)*err+a*Errorlast;//�˲�
	Errorlast=Errorout;
	ErrorInt += Errorout;
	
	ErrorInt=ErrorInt>20000?20000:(ErrorInt<(-20000)?(-20000):ErrorInt);
	
	t=Kp*Errorout+Ki*ErrorInt;
	return t;
}

void control(void)
{
	int pwm_out;
//	MPU6050_DMP_Get_Data(&Pitch,&Roll,&Yaw);
  
	t_out=Verspeed(Target,Actual,Actual2);
	jOut=Vertical(t_out,Pitch,gyro1);
	pwm_out=jOut;
	if(pwm_out>7200)
		pwm_out=7200;
	if(pwm_out<-7200)
		pwm_out=-7200;
	Out=-pwm_out;
	Out2=-pwm_out;
}



int main(void)
{
	delay_init();
  OLED_Init();
	MPU6050_DMP_Init();
//	Key_Init();
	Motor_Init();
	Encoder_Init();
  Encoder_Init2();
////	RP_Init();
//  Serial_Init();
	Timer_Init();


   Delay_ms(200);
	
	while(1)
	{	
			MPU6050_DMP_Get_Data(&Pitch,&Roll,&Yaw);
		MPU_Get_Gyroscope(&gyro1,&gyro2,&gyro3);

   Motor_SetPWM1(Out);
   Motor_SetPWM2(Out2);
		OLED_ShowString(3,1,"z:");
		OLED_ShowSignedNum(3,5,Pitch,3);
		OLED_ShowString(4,1,"GY:");
		OLED_ShowSignedNum(4,6,gyro2,5);
		

	}
}


//void TIM1_UP_IRQHandler(void)
//{
//	if (TIM_GetITStatus(TIM1, TIM_IT_Update) == SET)
//	{TIM_ClearITPendingBit(TIM1, TIM_IT_Update);
//	}
//}



void TIM1_UP_IRQHandler(void)
{
	
  	
			Actual2 = Encoder_Get2();	 
			Actual = Encoder_Get();		
			Count=0;
			control();
		
		
		TIM_ClearITPendingBit(TIM1, TIM_IT_Update);
	
}





	
//	if (TIM_GetITStatus(TIM1, TIM_IT_Update) == SET)
//	{
//		Count ++;
//		if(Count>=10)
//		{	
//				
//			jActual = Pitch;		
//			jError1 = Error0;
//			jError0 = jTarget - jActual;
////			
////				
////			jActual2 = Pitch+Out2;		
////			jError1_2 = Error0_2;
////			jError0_2 = jTarget - jActual;
//			
////			jOut2 = jKp * jError0 + jKd *jError0;
//			jOut = jKp * jError0 + jKd *jError0;
//			
//			if (jOut > 7200) {jOut = 7200;}
//			if (jOut < -7200) {jOut = -7200;}
////		  if (jOut2 > 7200) {jOut2 = 7200;}
////			if (jOut2 < -7200) {jOut2 = -7200;}
//			
//			
//			Count = 0;		
//			Actual2 = Encoder_Get2();		
//			Error1_2 = Error0_2;
//			Error0_2 = (Target2-jOut) - Actual2;
//			
//			if (Ki != 0)
//			{
//				ErrorInt_2 += Error0_2;
//			}
//			else
//			{
//				ErrorInt_2 = 0;
//			}
//			
//			Out2 = Kp * Error0_2 + Ki * ErrorInt_2 ;
//			
//			if (Out2 > 7200) {Out2 = 7200;}
//			if (Out2 < -7200) {Out2 = -7200;}
//	    Actual = Encoder_Get();		
//			Error1 = Error0;
//			Error0 = (Target-jOut) - Actual;
//			
//			if (Ki != 0)
//			{
//				ErrorInt += Error0;
//			}
//			else
//			{
//				ErrorInt = 0;
//			}
//			
//			Out = Kp * Error0 + Ki * ErrorInt ;
//			
//			if (Out > 7200) {Out = 7200;}
//			if (Out < -7200) {Out = -7200;}
//			
//		

//		}
//	


	
//		
//		if (Count >= 10)
//		{
//			Count = 0;		
//			Actual2 = Encoder_Get2();		
//			Error1_2 = Error0_2;
//			Error0_2 = Target2 - Actual2;
//			
//			if (Ki != 0)
//			{
//				ErrorInt_2 += Error0_2;
//			}
//			else
//			{
//				ErrorInt_2 = 0;
//			}
//			
//			Out2 = Kp * Error0_2 + Ki * ErrorInt_2 + Kd * (Error0_2 - Error1_2);
//			
//			if (Out2 > 1000) {Out2 = 1000;}
//			if (Out2 < -1000) {Out2 = -1000;}

//			Actual = Encoder_Get();		
//			Error1 = Error0;
//			Error0 = Target - Actual;
//			
//			if (Ki != 0)
//			{
//				ErrorInt += Error0;
//			}
//			else
//			{
//				ErrorInt = 0;
//			}
//			
//			Out = Kp * Error0 + Ki * ErrorInt + Kd * (Error0 - Error1);
//			
//			if (Out > 1000) {Out = 1000;}
//			if (Out < -1000) {Out = -1000;}

//			
//			
//			jActual = z;
//			jError0 = jTarget - jActual;
//			jOut = jKp * jError0 +  jKd * gyro[2];
//			jActual2 = z;
//			jError0_2 = jTarget2 - jActual2;
//			jOut2 = jKp * jError0_2 +  jKd * gyro[2];
//			
//			if (jOut > 500) {jOut = 500;}
//			if (jOut < -500) {jOut= -500;}

//		Out=-jOut;
//		Out2=-jOut2;

