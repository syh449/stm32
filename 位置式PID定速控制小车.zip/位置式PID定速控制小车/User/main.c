#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "LED.h"
#include "Timer.h"
#include "Key.h"
#include "RP.h"
#include "Motor.h"
#include "Encoder.h"
#include "Serial.h"
#include "PWM.h"

uint8_t KeyNum;
uint16_t Count;
float Target=40, Actual, Out;
float Kp=0.26, Ki=0.06, Kd=0.02;
float Error0, Error1, ErrorInt;
int out;
int16_t speed;
int16_t location;
int stu=0;

uint8_t Serial_RxData;		
uint8_t Serial_RxFlag;

void USART1_IRQHandler(void)
{
	if (USART_GetITStatus(USART1, USART_IT_RXNE) == SET)		//�ж��Ƿ���USART1�Ľ����¼��������ж�
	{
		Serial_RxData = USART_ReceiveData(USART1);				//��ȡ���ݼĴ���������ڽ��յ����ݱ���
     Serial_RxData=Serial_RxData;
		Serial_RxFlag = 1;										//�ý��ձ�־λ����Ϊ1
		USART_ClearITPendingBit(USART1, USART_IT_RXNE);			//���USART1��RXNE��־λ
																//��ȡ���ݼĴ������Զ�����˱�־λ
																//����Ѿ���ȡ�����ݼĴ�����Ҳ���Բ�ִ�д˴���
   if(Serial_RxData==0x00)
    {
     Target+=30;
		}
	  else if(Serial_RxData==0x01)
		{
     Target-=30;
		}
    else if(Serial_RxData==0x02)
		{
     Kp+=0.01;
		}
    else if(Serial_RxData==0x03)
		{
     Kp-=0.01;
		}
    else if(Serial_RxData==0x04)
		{
     Ki+=0.01;
		}
    else if(Serial_RxData==0x05)
		{
     Ki-=0.01;
		}
    else if(Serial_RxData==0x06)
		{
     Kd+=0.01;
		}
    else if(Serial_RxData==0x07)
		{
     Kd-=0.01;
		}
//    else if(Serial_RxData==0x08)
//		{
//     stu=8;
//		}
//    else if(Serial_RxData==0x09)
//		{
//     stu=9;
//		}
//    else if(Serial_RxData==0x10)
//		{
//     speed+=10;
//		}
//    else if(Serial_RxData==0x11)
//		{
//     speed-=10;
//		}


	}
}





int main(void)
{
	OLED_Init();
	Key_Init();
	Motor_Init();
	Encoder_Init();
//	RP_Init();
	Serial_Init();
	PWM_Init();
	Timer_Init();
//	
	//OLED_Printf(0, 0, OLED_8X16, "Speed Control");
 	OLED_Update();

	while (1)
	{
   Motor_SetPWM(-Out);
  OLED_Printf(0, 0, OLED_8X16, "Speed Control:%d",stu);
		OLED_Printf(0, 16, OLED_8X16, "Kp:%4.2f", Kp);
		OLED_Printf(0, 32, OLED_8X16, "Ki:%4.2f", Ki);
		OLED_Printf(0, 48, OLED_8X16, "Kd:%4.2f", Kd);
		
		OLED_Printf(64, 16, OLED_8X16, "Tar:%+04.0f", Target);
		OLED_Printf(64, 32, OLED_8X16, "Act:%+04.0f", Actual);
		OLED_Printf(64, 48, OLED_8X16, "Out:%+04.0f", Out);

		OLED_Update();
		KeyNum = Key_GetState();			
    

    if(KeyNum==2)
    {
     stu++;
     if(stu>=4)
      stu=0;
}

switch(stu)
{
    case 0: {  	if (KeyNum == 3)
		{KeyNum=0;
			Target+= 100;
		}
		if (KeyNum == 4)
		{KeyNum=0;
			Target -= 100;
		}  } break;
    case 1:  {  	if (KeyNum == 3)
		{KeyNum=0;
			Kp+= 0.01;
		}
		if (KeyNum == 4)
		{KeyNum=0;
			Kp -= 0.01;
		}  }    break;
    case 2: {  	if (KeyNum == 3)
		{KeyNum=0;
			Ki+= 0.01;
		}
		if (KeyNum == 4)
		{KeyNum=0;
			Ki -= 0.01;
		}  }       break;
    case 3:   {  	if (KeyNum == 3)
		{KeyNum=0;
			Kd+= 0.01;
		}
		if (KeyNum == 4)
		{KeyNum=0;
			Kd -= 0.01;
		}  }     break;
}


	
//		if (KeyNum == 3)
//		{
//			Target = 0;
//		}
		
//		Kp = RP_GetValue(1) / 4095.0 * 2;
//		Ki = RP_GetValue(2) / 4095.0 * 2;
//		Kd = RP_GetValue(3) / 4095.0 * 2;
//		Target = RP_GetValue(4) / 4095.0 * 300 - 150;
//		
//		OLED_Printf(0, 16, OLED_8X16, "Kp:%4.2f", Kp);
//		OLED_Printf(0, 32, OLED_8X16, "Ki:%4.2f", Ki);
//		OLED_Printf(0, 48, OLED_8X16, "Kd:%4.2f", Kd);
//		
//		OLED_Printf(64, 16, OLED_8X16, "Tar:%+04.0f", Target);
//		OLED_Printf(64, 32, OLED_8X16, "Act:%+04.0f", Actual);
//		OLED_Printf(64, 48, OLED_8X16, "Out:%+04.0f", Out);
//		
//		OLED_Update();
//		
		Serial_Printf("%f,%f,%f\r\n", Target, Actual, Out);
	}
}

////����������
//void TIM1_UP_IRQHandler(void)
//{
//   

//  if (TIM_GetITStatus(TIM1, TIM_IT_Update) == SET)
//	{
//          Count++;
//			if(Count>=40)
//			{
//				Count=0;
//			  speed=Encoder_Get();
//        location += speed;
//			}
//		TIM_ClearITPendingBit(TIM1, TIM_IT_Update);
//	}
//}



void TIM1_UP_IRQHandler(void)
{

	
	if (TIM_GetITStatus(TIM1, TIM_IT_Update) == SET)
	{
		Count ++;
		if (Count >= 40)
		{
			Count = 0;		
			Actual = Encoder_Get();		
			Error1 = Error0;
			Error0 = Target - Actual;
			
			if (Ki != 0)
			{
				ErrorInt += Error0;
			}
			else
			{
				ErrorInt = 0;
			}
			
			Out = Kp * Error0 + Ki * ErrorInt + Kd * (Error0 - Error1);
			
			if (Out > 100) {Out = 100;}
			if (Out < -100) {Out = -100;}

		}
		
		TIM_ClearITPendingBit(TIM1, TIM_IT_Update);
	}
}
