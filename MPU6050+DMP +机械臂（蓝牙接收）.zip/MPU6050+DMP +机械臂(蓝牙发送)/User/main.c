#include "stm32f10x.h"                  // Device header"
#include "OLED.h"
#include "Delay.h"
#include "inv_mpu.h"
#include "PWM.h"
#include "Serial.h"

float Pitch,Roll,Yaw;
int x,y,z;

int main(void)
{
	delay_init();
	OLED_Init();
  Serial_Init();
	MPU6050_DMP_Init();
	//myServo_Init(1999,719);
Delay_ms(200);
	
	while(1)
	{
		MPU6050_DMP_Get_Data(&Pitch,&Roll,&Yaw);
     z=(int)Pitch;
	   y=(int)Roll;
	   x=(int)Yaw;

if(x>0)
  Serial_SendByte(1) ;
else
{Serial_SendByte(0) ; x=-x;}
        Serial_SendByte(x/100) ;
        Serial_SendByte(x/10-x/100*10) ;
        Serial_SendByte(x%10) ;
if(y>0)
 Serial_SendByte(1) ;
else
{Serial_SendByte(0) ; y=-y;}
        Serial_SendByte(y/100) ;
        Serial_SendByte(y/10-x/100*10) ;
        Serial_SendByte(y%10) ;

if(z>0)
 Serial_SendByte(1) ;
else
{ Serial_SendByte(0) ; z=-z;}
        Serial_SendByte(z/100) ;
        Serial_SendByte(z/10-x/100*10) ;
        Serial_SendByte(z%10) ;
Serial_SendByte('A');


  	OLED_ShowString(1,1,"x:");
		OLED_ShowString(2,1,"y:");
		OLED_ShowString(3,1,"z:");
		OLED_ShowSignedNum(1,5,x,3);
		OLED_ShowSignedNum(2,5,y,3);
		OLED_ShowSignedNum(3,5,z,3);

	}
}
