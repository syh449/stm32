#ifndef __PWM_H
#define __PWM_H

void myServo_Init(u16 arr,u16 psc);
void Servo1(float i);
void Servo2(float i);
void Servo3(float i);
void Servo4(float i);
void Servo5(float i);
float slow_control(int a,float b,float c);

#endif
